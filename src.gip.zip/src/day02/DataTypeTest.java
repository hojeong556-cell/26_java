package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// 1) 기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 20;
		height = 189.5;
		weight = 90.12;
		
		
		// 2) 래퍼런스형 - 3개(배열,클래스,인터페이스)
		String name = "정호정";  //String name; name = "정호정";
		String s = new String("정호정");
		// 주소 adder
		String addr = "제주도";
		String d = new String("제주도");
		
		//Class 생성
		DataTypeTest dft = new DataTypeTest();
		
		// 3) 변수 값 출력하기, 출력 ctrl + f11
		System.out.println(isTrue);
		System.out.println("나이:"+age);
		System.out.println("키:"+height);
		System.out.println("몸무게:"+weight);
		System.out.println("이름:"+name);
		System.out.println("주소:"+addr);
		// + 연결 연산자
		
		

	}

}
