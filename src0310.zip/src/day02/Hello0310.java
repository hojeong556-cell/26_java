package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// printr계열 메소드를 이용해 자바로 하고싶은것 작성해서 출력하기
		System.out.println("Java로 실현 가능한것");
		System.out.println("정보 엔진 만들기");
		System.out.println("열심히 하겠습니다.");
		//System.out.print("3:19"); = System.out.print("\n3:19");
	}

}
